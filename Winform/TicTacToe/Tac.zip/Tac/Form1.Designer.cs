﻿namespace Tac
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_a = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_e = new System.Windows.Forms.Button();
            this.btn_f = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_h = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Label();
            this.select = new System.Windows.Forms.Label();
            this.draw = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_a
            // 
            this.btn_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_a.Location = new System.Drawing.Point(30, 70);
            this.btn_a.Name = "btn_a";
            this.btn_a.Size = new System.Drawing.Size(100, 100);
            this.btn_a.TabIndex = 0;
            this.btn_a.Text = "a";
            this.btn_a.UseVisualStyleBackColor = true;
            this.btn_a.Click += new System.EventHandler(this.btn_a_Click);
            // 
            // btn_b
            // 
            this.btn_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_b.Location = new System.Drawing.Point(142, 70);
            this.btn_b.Name = "btn_b";
            this.btn_b.Size = new System.Drawing.Size(100, 100);
            this.btn_b.TabIndex = 1;
            this.btn_b.Text = "b";
            this.btn_b.UseVisualStyleBackColor = true;
            this.btn_b.Click += new System.EventHandler(this.btn_b_Click);
            // 
            // btn_c
            // 
            this.btn_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_c.Location = new System.Drawing.Point(255, 70);
            this.btn_c.Name = "btn_c";
            this.btn_c.Size = new System.Drawing.Size(100, 100);
            this.btn_c.TabIndex = 2;
            this.btn_c.Text = "c";
            this.btn_c.UseVisualStyleBackColor = true;
            this.btn_c.Click += new System.EventHandler(this.btn_c_Click);
            // 
            // btn_d
            // 
            this.btn_d.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_d.Location = new System.Drawing.Point(30, 181);
            this.btn_d.Name = "btn_d";
            this.btn_d.Size = new System.Drawing.Size(100, 100);
            this.btn_d.TabIndex = 5;
            this.btn_d.Text = "d";
            this.btn_d.UseVisualStyleBackColor = true;
            this.btn_d.Click += new System.EventHandler(this.btn_d_Click);
            // 
            // btn_e
            // 
            this.btn_e.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_e.Location = new System.Drawing.Point(142, 181);
            this.btn_e.Name = "btn_e";
            this.btn_e.Size = new System.Drawing.Size(100, 100);
            this.btn_e.TabIndex = 4;
            this.btn_e.Text = "e";
            this.btn_e.UseVisualStyleBackColor = true;
            this.btn_e.Click += new System.EventHandler(this.btn_e_Click);
            // 
            // btn_f
            // 
            this.btn_f.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_f.Location = new System.Drawing.Point(255, 181);
            this.btn_f.Name = "btn_f";
            this.btn_f.Size = new System.Drawing.Size(100, 100);
            this.btn_f.TabIndex = 3;
            this.btn_f.Text = "f";
            this.btn_f.UseVisualStyleBackColor = true;
            this.btn_f.Click += new System.EventHandler(this.btn_f_Click);
            // 
            // btn_g
            // 
            this.btn_g.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_g.Location = new System.Drawing.Point(30, 293);
            this.btn_g.Name = "btn_g";
            this.btn_g.Size = new System.Drawing.Size(100, 100);
            this.btn_g.TabIndex = 8;
            this.btn_g.Text = "g";
            this.btn_g.UseVisualStyleBackColor = true;
            this.btn_g.Click += new System.EventHandler(this.btn_g_Click);
            // 
            // btn_h
            // 
            this.btn_h.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_h.Location = new System.Drawing.Point(142, 293);
            this.btn_h.Name = "btn_h";
            this.btn_h.Size = new System.Drawing.Size(100, 100);
            this.btn_h.TabIndex = 7;
            this.btn_h.Text = "h";
            this.btn_h.UseVisualStyleBackColor = true;
            this.btn_h.Click += new System.EventHandler(this.btn_h_Click);
            // 
            // btn_i
            // 
            this.btn_i.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_i.Location = new System.Drawing.Point(255, 293);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(100, 100);
            this.btn_i.TabIndex = 6;
            this.btn_i.Text = "i";
            this.btn_i.UseVisualStyleBackColor = true;
            this.btn_i.Click += new System.EventHandler(this.btn_i_Click);
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.result.Location = new System.Drawing.Point(31, 414);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(66, 25);
            this.result.TabIndex = 9;
            this.result.Text = "Result";
            // 
            // select
            // 
            this.select.AutoSize = true;
            this.select.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.select.Location = new System.Drawing.Point(31, 17);
            this.select.Name = "select";
            this.select.Size = new System.Drawing.Size(89, 25);
            this.select.TabIndex = 10;
            this.select.Text = "Selected";
            // 
            // draw
            // 
            this.draw.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.draw.Location = new System.Drawing.Point(272, 9);
            this.draw.Name = "draw";
            this.draw.Size = new System.Drawing.Size(100, 40);
            this.draw.TabIndex = 11;
            this.draw.Text = "Start";
            this.draw.UseVisualStyleBackColor = true;
            this.draw.Click += new System.EventHandler(this.draw_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 461);
            this.Controls.Add(this.draw);
            this.Controls.Add(this.select);
            this.Controls.Add(this.result);
            this.Controls.Add(this.btn_g);
            this.Controls.Add(this.btn_h);
            this.Controls.Add(this.btn_i);
            this.Controls.Add(this.btn_d);
            this.Controls.Add(this.btn_e);
            this.Controls.Add(this.btn_f);
            this.Controls.Add(this.btn_c);
            this.Controls.Add(this.btn_b);
            this.Controls.Add(this.btn_a);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_a;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_e;
        private System.Windows.Forms.Button btn_f;
        private System.Windows.Forms.Button btn_g;
        private System.Windows.Forms.Button btn_h;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.Label select;
        private System.Windows.Forms.Button draw;
    }
}

